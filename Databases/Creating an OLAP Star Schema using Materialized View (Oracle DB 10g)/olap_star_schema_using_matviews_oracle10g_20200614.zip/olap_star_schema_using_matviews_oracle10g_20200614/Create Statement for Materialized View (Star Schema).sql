CREATE MATERIALIZED VIEW ss_mv_total_sales_fact_table
  BUILD IMMEDIATE
  REFRESH FAST ON COMMIT
  ENABLE QUERY REWRITE
  AS
    SELECT tim.row_identifier AS time_interval, cust.country, cat.categoryname, count(ord.orderid) as count_orders
      FROM ss_time tim, ss_customers cust, ss_categories cat, ss_orders ord, ss_orderdetails odd, ss_products prd
      WHERE ord.customerid = cust.customerid
        AND odd.productid = prd.productid
        AND prd.categoryid = cat.categoryid
        AND tim.end_date >= ord.orderdate
        AND (tim.end_date - tim.time_span_in_days + 1) <= ord.orderdate
      GROUP BY tim.row_identifier, cust.country, cat.categoryname;

--DROP MATERIALIZED VIEW ss_mv_total_sales_fact_table;
SELECT * FROM ss_mv_total_sales_fact_table;
SELECT * FROM ss_mv_total_sales_fact_table where country = 'Germany' order by categoryname;
SELECT * FROM ss_mv_total_sales_fact_table where country = 'Germany' and time_interval = '1996';
SELECT * FROM ss_mv_total_sales_fact_table where country = 'Germany' and time_interval like '%1996%' order by categoryname;
