insert into ss_categories values(1,'Beverages','Soft drinks, coffees, teas, beers, and ales');
insert into ss_categories values(2,'Condiments','Sweet and savory sauces, relishes, spreads, and seasonings');
insert into ss_categories values(3,'Confections','Desserts, candies, and sweet breads');
insert into ss_categories values(4,'Dairy Products','Cheeses');
insert into ss_categories values(5,'Grains/Cereals','Breads, crackers, pasta, and cereal');
insert into ss_categories values(6,'Meat/Poultry','Prepared meats');
insert into ss_categories values(7,'Produce','Dried fruit and bean curd');
insert into ss_categories values(8,'Seafood','Seaweed and fish');
commit;